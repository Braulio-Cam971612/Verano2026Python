#datoa, datob, resultado

class calculadoraModell:

    def __init__(self, datoa, datob):
        self.datoa=datoa
        self.datob=datob

    def presntardatos(self):
        return "Haciendo operaciones con datoa: ", self.datoa, " con datob: ", self.datob    
    #self = this
    def sumar(self):
        return self.datoa + self.datob
    def restar(self):
        return self.datoa - self.datob
    def dividir(self):
        return self.datoa / self.datob
    def multiplicar(self):
        return self.datoa * self.datob            