#Es el encargado de llamar los archivos view

#Comento hacer un calculadora
#datoa, datob, resultado

#terminemos----

#llamar el controlador, 
from controller.calculadoraController import calculadoraController
from controller.personaController import personaController

def principal():
#pasar parametros

    print("Registro de persona")
    nombre = input("Ingresa el nombre: ")
    edad = input("Ingresa la edad: ")
    genero = input("Ingrese el genero: ")

    _personaController = personaController()
    _personaModel = _personaController.crearPersona(nombre, edad, genero)

    _personaController.mostrarDatos(_personaModel)






    datoa = int(input("Ingresa el datoa: "))
    datob = int(input("Ingresa el datob: "))

    #instancia o declarar la clase una variable
    _calculadoraController = calculadoraController()

    #creemos el modelo
    modelo_calculadoraModell = _calculadoraController.agregardatos(datoa, datob)

    print("\n=== Operaciones en MVC===")
    print("1. Sumar")
    print("2. Restar")
    print("3. Dividir")
    print("4. Multiplicar")


    opcion = int(input("Seleccione una operacion (1--4)"))

    _calculadoraController.operaciones(modelo_calculadoraModell, opcion)


    _calculadoraController.presntardatos(modelo_calculadoraModell)

    #aca deberia llamar ....

principal()    

